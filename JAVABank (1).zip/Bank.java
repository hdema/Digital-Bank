package com.company;

import java.util.*;


class Bank
{
    Map<String, Account> accountMap;
    Bank()
    {
        accountMap = new HashMap <String, Account>();
    }
    public static void main(String []args)
    {
        Scanner sc  =  new Scanner(System.in);
        Account account;
        String username,password;
        double amount;
        int accountType;
        Bank bank  =  new Bank();
        int choice;
        outer:	while(true)
        {
            System.out.println("\n-------------------");
            System.out.println("     JAVA Bank     ");
            System.out.println("-------------------\n");
            System.out.println("1. Register account.");
            System.out.println("2. Login.");
            System.out.println("3. add Revenue to a saving account.");
            System.out.println("4. display user accounts");
            System.out.println("5. Exit.");
            System.out.print("\nEnter your choice : ");
            choice = sc.nextInt();
            sc.nextLine();
            switch(choice)
            {
                case 1:
                    System.out.print("choose account type : \n1 - current account\n2 - savings account ");
                    accountType = sc.nextInt();
                    while(accountType < 1 || accountType > 2)
                    {
                        System.out.println("Invalid account type. Enter again :");
                        accountType = sc.nextInt() ;
                    }
                    sc.nextLine();
                    System.out.print("Enter name : ");
                    String name = sc.nextLine();
                    System.out.print("Enter address : ");
                    String address = sc.nextLine();
                    System.out.print("Enter contact number : ");
                    String phone = sc.nextLine();
                    System.out.println("Set username : ");
                    username = sc.next();
                    while(bank.accountMap.containsKey(username))
                    {
                        System.out.println("Username already exists. Set again : ");
                        username = sc.next();
                    }
                    System.out.println("Set a password (minimum 6 characters) :");
                    password = sc.next();
                    sc.nextLine();
                    while(password.length() < 6)
                    {
                        System.out.println("Invalid password, Enter again :");
                        password=sc.next();
                    }
                    System.out.print("Enter initial deposit : ");
                    while(!sc.hasNextDouble())
                    {
                        System.out.println("Invalid amount. Enter again :");
                        sc.nextLine();
                    }
                    amount=sc.nextDouble();
                    if(accountType == 2){
                        while (amount < SavingsAccount.MIN_LIMIT){
                            System.out.println("Savings accounts have a 5000 SAR on the initial deposit you can not create account with this amount, enter again :");
                            amount = sc.nextDouble();
                        }
                    }
                    sc.nextLine();
                    if(accountType == 1){
                        account = new CurrentAccount(username,password,name,address,phone,amount,new Date());
                        bank.accountMap.put(username, account);
                    }
                    else if(accountType == 2){
                        account = new SavingsAccount(username,password,name,address,phone,amount,new Date());
                        bank.accountMap.put(username, account);
                    }
                    break;
                case 2:
                    System.out.println("Enter username : ");
                    username = sc.next();
                    sc.nextLine();
                    System.out.println("Enter password : ");
                    password = sc.next();
                    sc.nextLine();
                    if(bank.accountMap.containsKey(username))
                    {
                        account = bank.accountMap.get(username);
                        SavingsAccount savingsAccount;
                        CurrentAccount currentAccount;
                        if(account instanceof CurrentAccount){
                            currentAccount = (CurrentAccount) account;
                            if(account.password.equals(password))
                            {

                                while(true)
                                {
                                    System.out.println("\n-------------------");
                                    System.out.println("W  E  L  C  O  M  E");
                                    System.out.println("-------------------\n");
                                    System.out.println("1. Deposit.");
                                    System.out.println("2. Transfer.");
                                    System.out.println("3. Last 5 transactions.");
                                    System.out.println("4. User information.");
                                    System.out.println("5. Log out.");
                                    System.out.print("\nEnter your choice : ");
                                    choice = sc.nextInt();
                                    sc.nextLine();
                                    switch(choice)
                                    {
                                        case 1:
                                            System.out.print("Enter amount : ");
                                            while(!sc.hasNextDouble())
                                            {
                                                System.out.println("Invalid amount. Enter again :");
                                                sc.nextLine();
                                            }
                                            amount = sc.nextDouble();
                                            sc.nextLine();
                                            currentAccount.deposit(amount,new Date());
                                            break;
                                        case 2:
                                            System.out.print("Enter payee username : ");
                                            username = sc.next();
                                            sc.nextLine();
                                            System.out.println("Enter amount : ");
                                            while(!sc.hasNextDouble())
                                            {
                                                System.out.println("Invalid amount. Enter again :");
                                                sc.nextLine();
                                            }
                                            amount = sc.nextDouble();
                                            sc.nextLine();
                                            if(amount > 300000)
                                            {
                                                System.out.println("Transfer limit exceeded. Contact bank manager.");
                                                break;
                                            }
                                            if(bank.accountMap.containsKey(username))
                                            {
                                                Account payee = bank.accountMap.get(username);
                                                SavingsAccount savingsPayee;
                                                CurrentAccount currentPayee;
                                                if(payee instanceof SavingsAccount){
                                                    savingsPayee = (SavingsAccount) payee;
                                                    savingsPayee.deposit(amount,new Date());
                                                    currentAccount.withdraw(amount,new Date());
                                                }else {
                                                    currentPayee = (CurrentAccount) payee;
                                                    currentPayee.deposit(amount,new Date());
                                                    currentAccount.withdraw(amount,new Date());
                                                }

                                            }
                                            else
                                            {
                                                System.out.println("Username doesn't exist.");
                                            }
                                            break;
                                        case 3:
                                            for(String transactions : account.transactions)
                                            {
                                                System.out.println(transactions);
                                            }
                                            break;
                                        case 4:
                                            System.out.println("name : "+ account.name);
                                            System.out.println("address : "+ account.address);
                                            System.out.println("contact : "+ account.phone);
                                            break;
                                        case 5:
                                            continue outer;
                                        default:
                                            System.out.println("Wrong choice !");
                                    }
                                }
                            }
                            else
                            {
                                System.out.println("Wrong username/password.");
                            }

                        }else if(account instanceof SavingsAccount){
                            savingsAccount = (SavingsAccount) account;
                            if(account.password.equals(password))
                            {

                                while(true)
                                {
                                    System.out.println("\n********************");
                                    System.out.println("W  E  L  C  O  M  E");
                                    System.out.println("\n********************\n");
                                    System.out.println("1. Deposit.");
                                    System.out.println("2. Transfer.");
                                    System.out.println("3. Last 5 transactions.");
                                    System.out.println("4. User information.");
                                    System.out.println("5. Log out.");
                                    System.out.print("\nEnter your choice : ");
                                    choice = sc.nextInt();
                                    sc.nextLine();
                                    switch(choice)
                                    {
                                        case 1:
                                            System.out.print("Enter amount : ");
                                            while(!sc.hasNextDouble())
                                            {
                                                System.out.println("Invalid amount. Enter again :");
                                                sc.nextLine();
                                            }
                                            amount = sc.nextDouble();
                                            sc.nextLine();
                                            savingsAccount.deposit(amount,new Date());
                                            break;
                                        case 2:
                                            System.out.print("Enter payee username : ");
                                            username = sc.next();
                                            sc.nextLine();
                                            System.out.println("Enter amount : ");
                                            while(!sc.hasNextDouble())
                                            {
                                                System.out.println("Invalid amount. Enter again :");
                                                sc.nextLine();
                                            }
                                            amount = sc.nextDouble();
                                            sc.nextLine();
                                            if(amount > 300000)
                                            {
                                                System.out.println("Transfer limit exceeded. Contact bank manager.");
                                                break;
                                            }
                                            if(bank.accountMap.containsKey(username))
                                            {
                                                Account payee = bank.accountMap.get(username);
                                                SavingsAccount savingsPayee;
                                                CurrentAccount currentPayee;
                                                if(payee instanceof SavingsAccount){
                                                    savingsPayee = (SavingsAccount) payee;
                                                    savingsPayee.deposit(amount,new Date());
                                                    savingsAccount.withdraw(amount,new Date());
                                                }else {
                                                    currentPayee = (CurrentAccount) payee;
                                                    currentPayee.deposit(amount,new Date());
                                                    savingsAccount.withdraw(amount,new Date());
                                                }
                                            }
                                            else
                                            {
                                                System.out.println("Username doesn't exist.");
                                            }
                                            break;
                                        case 3:
                                            for(String transactions : account.transactions)
                                            {
                                                System.out.println(transactions);
                                            }
                                            break;
                                        case 4:
                                            System.out.println("name : "+ account.name);
                                            System.out.println("address : "+ account.address);
                                            System.out.println("contact : "+ account.phone);
                                            break;
                                        case 5:
                                            continue outer;
                                        default:
                                            System.out.println("Wrong choice !");
                                    }
                                }
                            }
                            else
                            {
                                System.out.println("Wrong username/password.");
                            }
                        }


                    }
                    else
                    {
                        System.out.println("Wrong username/password.");
                    }
                    break;
                case 3:
                    System.out.println("Enter username : ");
                    username = sc.next();
                    sc.nextLine();
                    double ammount = 0.00;
                    if(bank.accountMap.containsKey(username))
                    {
                        Account user = bank.accountMap.get(username);
                        if(user instanceof SavingsAccount){
                            SavingsAccount savingsAccount = (SavingsAccount) user;
                            System.out.println("Enter amount : ");
                            while(!sc.hasNextDouble())
                            {
                                System.out.println("Invalid amount. Enter again :");
                                sc.nextLine();
                            }
                            ammount = sc.nextDouble();
                            savingsAccount.addRevenue(new Date(), ammount);
                        }else {
                            System.out.println("this is not a savings account, please choose savings account first");
                        }

                    }
                    else
                    {
                        System.out.println("Username doesn't exist.");
                    }
                    break;
                case 4:
                    Set<String> keys = bank.accountMap.keySet();
                    final String SEPARATOR = "     |     ";
                    System.out.println("user name" + SEPARATOR + "address" + SEPARATOR + "phone number" + SEPARATOR + "balance");
                    for(String userName : keys){
                        Account details = bank.accountMap.get(userName);
                        System.out.println(details.name + SEPARATOR + details.address + SEPARATOR + details.phone + SEPARATOR + details.balance);

                    }
                    break;
                case 5:
                    System.out.println("\nThank you for choosing JAVA Bank.");
                    System.exit(1);
                    break;
                default:
                    System.out.println("Wrong choice !");
            }
        }
    }
}