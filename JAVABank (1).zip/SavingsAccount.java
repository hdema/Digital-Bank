package com.company;

import java.text.NumberFormat;
import java.util.Date;

class SavingsAccount extends Account {

    public static final int MIN_LIMIT = 5000;
    private static final int TRANSACTIONS_LIMIT = 10;
    private static final int WITHDRAW_COST = 200;
    private final int type = 2;

    SavingsAccount(String username, String password, String name, String address, String phone, double balance, Date date) {
        super(username, password, name, address, phone, balance, date);
        addTransaction(String.format("Initial deposit for savings account - " + NumberFormat.getCurrencyInstance().format(balance)+" as on " + "%1$tD"+" at "+"%1$tT.",date));
    }

    //only for savings account
    void addRevenue(Date date, double ammount)
    {
        deposit(ammount, date);
    }

    @Override
    public void deposit(double amount,Date date)
    {
        balance += amount;
        addTransaction(String.format(NumberFormat.getCurrencyInstance().format(amount)+" credited to your account. Balance - " +NumberFormat.getCurrencyInstance().format(balance)+" as on " + "%1$tD"+" at "+"%1$tT.",date));
    }

    @Override
    public void withdraw(double amount,Date date)
    {
        if(amount>(balance-WITHDRAW_COST))
        {
            System.out.println("Insufficient balance.");
            return;
        }
        balance -= amount;
        balance -= WITHDRAW_COST;
        addTransaction(String.format(NumberFormat.getCurrencyInstance().format(amount)+" debited from your account. Balance - " +NumberFormat.getCurrencyInstance().format(balance)+" as on " + "%1$tD"+" at "+"%1$tT.",date));
    }

    @Override
    public void addTransaction(String message)
    {
        transactions.add(0,message);
        if(transactions.size()>TRANSACTIONS_LIMIT)
        {
            transactions.remove(TRANSACTIONS_LIMIT);
            transactions.trimToSize();
        }
    }

    public int getType() {
        return type;
    }
}