package com.company;

import java.text.NumberFormat;
import java.util.Date;
import java.util.Locale;

class CurrentAccount extends Account {

    public static final int MIN_LIMIT = 0;
    private static final int TRANSACTIONS_LIMIT = 5;
    private static final int WITHDRAW_COST = 0;
    private final int type = 1;

    CurrentAccount(String username, String password, String name, String address, String phone, double balance, Date date) {
        super(username, password, name, address, phone, balance, date);
        addTransaction(String.format("Initial deposit for current account - " + NumberFormat.getCurrencyInstance(Locale.forLanguageTag("ar-SA")).format(balance)+" as on " + "%1$tD"+" at "+"%1$tT.",date));

    }

    @Override
    public void deposit(double amount,Date date)
    {
        balance += amount;
        addTransaction(String.format(NumberFormat.getCurrencyInstance().format(amount)+" credited to your account. Balance - " +NumberFormat.getCurrencyInstance().format(balance)+" as on " + "%1$tD"+" at "+"%1$tT.",date));
    }

    @Override
    public void withdraw(double amount,Date date)
    {
        if(amount>(balance-WITHDRAW_COST))
        {
            System.out.println("Insufficient balance.");
            return;
        }
        balance -= amount;
        addTransaction(String.format(NumberFormat.getCurrencyInstance().format(amount)+" debited from your account. Balance - " +NumberFormat.getCurrencyInstance().format(balance)+" as on " + "%1$tD"+" at "+"%1$tT.",date));
    }

    @Override
    public void addTransaction(String message)
    {
        transactions.add(0,message);
        if(transactions.size()>TRANSACTIONS_LIMIT)
        {
            transactions.remove(TRANSACTIONS_LIMIT);
            transactions.trimToSize();
        }
    }

    public int getType() {
        return type;
    }


}
