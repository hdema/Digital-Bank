package com.company;

import java.util.ArrayList;
import java.util.Date;

abstract class Account
{
    public String username,password,name,address,phone;
    public double balance;
    ArrayList<String> transactions;
    Account(String username, String password, String name, String address, String phone, double balance, Date date)
    {
        this.username = username;
        this.password = password;
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.balance = balance;
        transactions  =  new ArrayList<String>(5);
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }


    public abstract void addTransaction(String message);
    public abstract void withdraw(double amount,Date date);
    public abstract void deposit(double amount,Date date);
}
